<?php

   include('config/database.php');
   $uname=$phone_no=$email=$address=$city="";
    if(isset($_POST['submit']))
        {
            $uname = $_POST['uname'];
            $phone_no = $_POST['phone_no'];
            $email = $_POST['email'];
            $address = $_POST['address'];
            $city = $_POST['city'];
            $connection->query("INSERT INTO leads (uname, phone_no, email, address, city) VALUES ('$uname', '$phone_no', '$email', '$address', '$city')");
        if(!$connection) 
        { echo mysqli_error(); }
    else
    {
        header("Location: home.php");
    }

         }  
 ?>
 <!DOCTYPE html>
 <html>
 <head>
<style>
.error {color: #FF0000;}
</style>
 </head>
 <body>
 <?php include('Templates/header.php'); ?>
 <div class="container">
  <center><h2>Add Details</h2></center><br><br>
  <form class="form-horizontal" action="add_details.php" method="POST">
     <div class="form-group">
      <label class="control-label col-md-4" for="uname">Name:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="uname" placeholder="Enter Name" name="uname">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="email">Email:</label>
      <div class="col-md-4">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="phone_no">Mobile:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="phone_no" placeholder="Enter Mobile" name="phone_no">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="address">Address:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="address" placeholder="Enter Address" name="address">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="city">City:</label>
      <div class="col-md-4">          
    <select name="city" class="col-md-4">
    <option value="1">Bangalore</option>
    <option value="2">Hubli</option>
    <option value="3">Mysore</option>
  </select>
      </div>
    </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-5 col-md-4">
        <button type="submit"name="submit" class="btn btn-primary text-center"><span><i class="fa fa-plus-circle" aria-hidden="true"></i>  </span>Submit</button>
        <a href="home.php" class="btn btn-warning btn-flat" style="box-shadow: 0 2px 4px 0 rgba(255, 255, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2); width:30%;"> <i class="fa fa-undo"></i> Back</a>
      </div>
    </div>
  </form>
</div>



 <?php include('Templates/footer.php'); ?>
 </body>
 </html>
 