<?php 
include('config/database.php');
session_start();
 ?>
 <style type="text/css">
 	h3{
     color: #7a5691;
 	}
 	
 </style>
  <body>
 <?php  include('Templates/header.php'); ?>
 <div class="container text-center">
 	 <?php if(!isset($_SESSION["sess_user"])){
  header("location:login.php");
} else {
 ?>
 	<?php 
         $id=$_REQUEST['id'];
          $result = $connection->query("DELETE from leads WHERE sno='$id'");
 	       
			header("Location: home.php");
			?>
            <h3> SuccessFully Deleted</h3><br>
			

 	<?php } ?>
 	
 </div>

 <?php  include('Templates/footer.php'); ?>
</body>

