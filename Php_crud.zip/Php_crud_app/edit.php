<?php
  include('config/database.php');
  session_start();?>
    <?php if(!isset($_SESSION["sess_user"])){
  header("location:login.php");
} else {
 ?><?php
  if(isset($_POST['update']))
        {   $id = $_POST['sno'];
            $uname = $_POST['uname'];
            $phone_no = $_POST['phone_no'];
            $email = $_POST['email'];
            $address = $_POST['address'];
            $city = $_POST['city'];
           $result = mysqli_query($connection, "UPDATE leads SET uname='$uname',email='$email',phone_no='$phone_no',address='$address',city='$city' WHERE sno=$id");
         header("Location: home.php");

         }  

?><?php } ?>

<?php 
$id='';
$id=$_REQUEST['id'];
$query = "SELECT * from leads where sno='".$id."'"; 
      $result = mysqli_query($connection, $query) or die ( mysqli_error());
      $row = mysqli_fetch_assoc($result); ?>


<!DOCTYPE html>
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
 </head>
 <body>
 <?php include('Templates/header.php'); ?>
 <div class="container">
  <center><h2>Edit Details</h2></center><br><br>
  <form class="form-horizontal" action="edit.php" method="POST">
     <div class="form-group">
      <label class="control-label col-md-4" for="uname">Name:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="uname" value="<?php echo $row['uname']; ?>" placeholder="Enter Name" name="uname">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="email">Email:</label>
      <div class="col-md-4">
        <input type="email" class="form-control" id="email" value="<?php echo $row['email']; ?>" placeholder="Enter email" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="phone_no">Mobile:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="phone_no" value="<?php echo $row['phone_no']; ?>" placeholder="Enter Mobile" name="phone_no">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="address">Address:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="address" value="<?php echo $row['address']; ?>" placeholder="Enter Address" name="address">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="city">City:</label>
      <div class="col-md-4">          
        <input type="text" class="form-control" id="city" value="<?php echo $row['city']; ?>" placeholder="Enter City" name="city">
      </div>
    </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-5 col-md-4">
        <td><input type="hidden" name="sno" value=<?php echo $_GET['id'];?>></td>
        <button type="submit" name="update" class="btn btn-primary text-center"><span><i class="fa fa-plus-circle" aria-hidden="true"></i>  </span>Submit</button>
         <a href="home.php" class="btn btn-warning btn-flat" style="box-shadow: 0 2px 4px 0 rgba(255, 255, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2); width:30%;"> <i class="fa fa-undo"></i> Back</a>
      </div>
    </div>
  </form>
</div>



 <?php include('Templates/footer.php'); ?>
 </body>
 </html>
 