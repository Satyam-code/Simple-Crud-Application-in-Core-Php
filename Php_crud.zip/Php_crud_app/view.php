<?php 
include('config/database.php');
session_start();
 ?>
 <style type="text/css">
 	.test,h2{
     color: #2587fa;
     font-size: 40%;
     font-weight:50%;
 	}
 	label{
     color: #2e2ec7;
 	}
 	b{
     color: #7a5691;
 	}
 </style>
  <body>
 <?php  include('Templates/header.php'); ?>
 
 	
 
 <div class="container">
 	<?php if(!isset($_SESSION["sess_user"])){
  header("location:login.php");
} else {
 ?>
 	<?php 

 	     $id=$_REQUEST['id'];
			$query = "SELECT * from leads where sno='".$id."'"; 
			$result = mysqli_query($connection, $query) or die ( mysqli_error());
			$row = mysqli_fetch_assoc($result); ?>

			<center class="test"><h2>View Detail</h2></center>

            <!-- <h3> <label>Serial No:&nbsp; </label><b> <?php echo $row['sno']; ?></b></h3><br> -->
			<h3> <label>Name: &nbsp;&nbsp;</label><b><?php echo $row['uname']; ?></b></h3><br>
			<h3> <label>Mobile:&nbsp;&nbsp; </label><b><?php echo $row['phone_no']; ?></b></h3><br>
			<h3> <label>E-Mail: &nbsp;&nbsp;</label><b><?php echo $row['email']; ?></b></h3><br>
			<h3> <label>Address: &nbsp;&nbsp;</label><b><?php echo $row['address']; ?></b></h3><br>
			<?php } ?>
 </div>

 <div class="text-center">
 	<a href="home.php" class="btn btn-warning btn-flat" style="box-shadow: 0 2px 4px 0 rgba(255, 255, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2); width:30%;"> <i class="fa fa-undo"></i> Back</a>
 </div>

 <?php  include('Templates/footer.php'); ?>
</body>

