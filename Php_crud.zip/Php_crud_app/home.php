<?php 
include('config/database.php');
session_start();
?>
 
 <body>
 <?php include('Templates/header.php'); ?>

   <div class="container">
  <b><h2 class="text-center" style="color:#0467db;font-size: 40px; font-weight: 30px;">Lead Details</h2></b><br>
     <div class="container text-right">
     	<a class="btn btn-primary" href="add_details.php" data-toggle="tooltip" title="Add Record"><i class="fa fa-plus" aria-hidden="true"></i> Add Record </a>
     </div>  <br>                                                        
  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>S.No.</th>
        <th>Name</th>
        <th>Mobile</th>
        <th>E-Mail</th>
        <th>Address</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr> <?php if(!isset($_SESSION["sess_user"])){
  header("location:login.php");
} else {
 ?>
           <?php   
			  $result = $connection->query('SELECT * FROM leads');?>
     <?php   $counter = 0;?>
			 
			  <?php foreach ($result as $res){ ?>
			  	    <?php $id=$res['sno'] ; ?>
				        
					    <td><?php echo ++$counter; ?></td>
				        <td><?php echo $res['uname'] ; ?></td>
				        <td><?php echo $res['phone_no'] ; ?></td>
				        <td><?php echo $res['email'] ; ?></td>
				        <td><?php echo $res['address'] ; ?></td>
				        <td> <a class="btn btn-warning btn-sm" href="view.php?id=<?php echo $res["sno"]; ?>" data-toggle="tooltip" title="View Details"><i class="fa fa-eye"></i> View </a>
				        <a class="btn btn-primary btn-sm" href="edit.php?id=<?php echo $res["sno"]; ?>" data-toggle="tooltip" title="Edit Details"><i class="fa fa-pencil-square-o"></i> Edit </a>
				    <a class="btn btn-danger btn-sm" href="delete.php?id=<?php echo $res["sno"]; ?>" data-toggle="tooltip" title="Delete Details"><i class="fa fa-trash-o"></i> Delete </a>
				</td>

				
      </tr><?php } ?><?php } ?>
    </tbody>
  </table>
  </div>
</div>
  <?php include('Templates/footer.php') ?>
 </body>
 </html>