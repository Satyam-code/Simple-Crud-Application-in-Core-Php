<style type="text/css">
	p{   
		margin: 10px;
		padding: 20px;
	}
</style>
<b><p class="text-center" style="color:#8a7a79">copyright@ 2019</p></b>