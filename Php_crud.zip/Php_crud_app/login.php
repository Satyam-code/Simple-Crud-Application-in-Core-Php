<?php
if(isset($_POST["submit"])){

if(!empty($_POST['email']) && !empty($_POST['password'])) {
    $email=$_POST['email'];
    $password=$_POST['password'];
    $password=md5($password);
  
    include("db.php"); 

    $query=mysqli_query($con,"SELECT * FROM register WHERE email='".$email."' AND password='".$password."'");
    $numrows=mysqli_num_rows($query);
    if($numrows!=0)
    {
    while($row=mysqli_fetch_assoc($query))
    {
    $dbusername=$row['email'];
    $dbpassword=$row['password'];
    }

    if($email == $dbusername && $password == $dbpassword)
    {
    session_start();
    $_SESSION['sess_user']=$email;

    /* Redirect browser */
    header("Location: home.php");
    }
    } else {
    echo "<h3>Invalid username or password!</h3>";
    }

} else {
    echo "All fields are required!";
}
}
?>

<style type="text/css">
    *{
        margin: 0px;
        padding: 0px;
    }
    body{
        background-color:#f1f1f1;
        
        
    }
    h3{
        text-align: center;
    }
	.login-form {
		width: 340px;
    	margin: 50px auto;
	}
    .login-form form {
    	margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .btn {        
        font-size: 15px;
        font-weight: bold;
    }
</style>

<body>
     <?php include('Templates/header.php'); ?>
     <h1 style="text-align: center;color: blue;">Login Form</h1>
    
<div class="login-form">
    <form action="" method="POST">
        <h2 class="text-center">Log in</h2>       
        <div class="form-group">
            <input type="text" class="form-control" placeholder="E-Mail" name="email" required="required">
        </div>
        <div class="form-group">
            <input type="password" class="form-control" placeholder="Password" name="password" required="required">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block" name="submit">Log in</button>
        </div>
             
    </form>
    <p class="text-center"><a href="register.php">Create an Account</a></p>
</div>
</body>
                               		                            