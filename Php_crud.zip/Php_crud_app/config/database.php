<?php 
 $server ='localhost';
 $username ='root';
 $password ='';
 $database ='project';

 $connection = mysqli_connect($server,$username,$password,$database);

 if (!$connection) {
 	die("Conncetion Failed" . mysqli_connect_error());
 }

 ?>